--   --CAPSTONE PROJECT--   --

CREATE DATABASE CAPSTONE;              -- Creating New Database.

USE CAPSTONE;                          -- Activating/Using the Database

SELECT * FROM BANK_FINAL_DATA;         -- Checking the data set. All 49732 records has been appeared in the output.

-- Assignment Queries--

-- 1.Write an SQL query to identify the age group which is taking more loan and then calculate the sum of all of the balances of it?

SELECT AGE, COUNT(LOAN) AS NO_OF_LOANS, SUM(BALANCE) FROM BANK_FINAL_DATA
WHERE LOAN = 'YES'
GROUP BY AGE
ORDER BY LOAN DESC;

-- Reply: Customers who is around 33 age group hasve taken 339 loans with total loan amount of 259536

-- 2.Write an SQL query to calculate for each record if a loan has been taken less than 100, 
-- then  calculate the fine of 15% of the current balance and create a temp table and     
-- then add the amount for each month from that temp table? 



-- 3.Write an SQL query to calculate each age group along with each department's highest balance record? 

SELECT AGE, JOB, BALANCE FROM BANK_FINAL_DATA
GROUP BY AGE, JOB
ORDER BY BALANCE DESC;

-- Reply: Output showing the Age group, Department and Balance
-- Employees from Services department is having more balance with 69 age.

-- 4.Write an SQL query to find the secondary highest education, where duration is more than 150. 
-- The query should contain only married people, and then calculate the interest amount? (Formula interest => balance*15%).

SELECT MARITAL, BALANCE*0.15 AS INTEREST, EDUCATION FROM BANK_FINAL_DATA
WHERE MARITAL = 'MARRIED' AND DURATION >150 AND EDUCATION = 'SECONDARY';

-- Reply: Displaying interest amount for married people having secondary grade in education.

-- 5.Write an SQL query to find which profession has taken more loan along with age?

SELECT JOB, AGE, COUNT(LOAN) AS NO_OF_LOANS FROM BANK_FINAL_DATA 
GROUP BY JOB, AGE
ORDER BY NO_OF_LOANS DESC
LIMIT 1;

-- Reply:  Management profession has 556 number of loans with age group 32

-- 6.Write an SQL query to calculate each month's total balance and then calculate in which month the 
-- highest amount of transaction was performed?

SELECT MONTH, SUM(BALANCE) FROM BANK_FINAL_DATA
GROUP BY AGE, JOB
ORDER BY BALANCE DESC;

-- Reply: July month has highest amount of transaction.